<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PhotoController@index');
Route::post('/indexsearch', 'PhotoController@indexSearch')->name('indexsearch');
Route::get('/trendsearch', 'PhotoController@trendSearch')->name('trendsearch');
Route::get('/newsearch', 'PhotoController@newSearch')->name('newsearch');
Route::get('/searchdetail', 'PhotoController@searchDetail');
Route::post('/searchdetailresult', 'PhotoController@searchDetailResult');

Route::get('users/mypage', 'UserController@mypage')->name('mypage');
Route::get('users/mypage/edit', 'UserController@edit')->name('mypage.edit');
Route::get('users/mypage/icon/edit', 'UserController@edit_icon')->name('mypage.edit_icon');
Route::put('users/mypage', 'UserController@update')->name('mypage.update');
Route::get('users/mypage/password/edit', 'UserController@edit_password')->name('mypage.edit_password');
Route::put('users/mypage/password', 'UserController@update_password')->name('mypage.update_password');

Route::get('users/mypage/photolist', 'UserController@photo_list')->name('mypage.photo_list');
Route::get('users/mypage/reviewlist', 'UserController@review_list')->name('mypage.review_list');
Route::get('users/mypage/favoritelist', 'UserController@favorite_list')->name('mypage.favorite_list');


Route::post('photos/{photo}/reviews', 'ReviewController@store');
Route::get('photos/{photo}/favorite', 'PhotoController@favorite')->name('photos.favorite');

Route::resource('photos', 'PhotoController');
Auth::routes(['verify' => true]);

if (env('APP_ENV') === 'local') {
   URL::forceScheme('https');
} 
