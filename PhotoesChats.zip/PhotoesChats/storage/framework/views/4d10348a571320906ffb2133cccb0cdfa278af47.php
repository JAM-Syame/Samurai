<?php $__env->startSection('content'); ?>
  	<h2>お気に入り一覧</h2>
		<?php if($favoritelist != null): ?>
        <div class="row">
            <?php $__currentLoopData = $favoritelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="offset-md-5 col-md-5">
                <p class="h3"><?php echo e(App\Photo::find($favorite->favoriteable_id)->title); ?></p>
                <div><img src="<?php echo e($url); ?>photos/<?php echo e($user->id); ?>/<?php echo e(App\Photo::find($favorite->favoriteable_id)->url); ?>"/></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
	

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ec2-user/environment/sharephoto/resources/views/users/favorite_list.blade.php ENDPATH**/ ?>