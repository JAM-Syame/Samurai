<?php $__env->startSection('title', 'レビュー一覧'); ?>

<?php $__env->startSection('content'); ?>
  	<h2>PhotoList</h2>
		<?php if($reviewlist != null): ?>
        <div class="row">
            <?php $__currentLoopData = $reviewlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="offset-md-5 col-md-5">
                <p class="h3"><?php echo e(App\Photo::find($review->photo_id)->title); ?></p>
                <div><?php echo e($review->content); ?></div>
                <div><img src="<?php echo e($url); ?>photos/<?php echo e($user->id); ?>/<?php echo e(App\Photo::find($review->photo_id)->url); ?>"/></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
	

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ec2-user/environment/sharephoto/resources/views/users/review_list.blade.php ENDPATH**/ ?>