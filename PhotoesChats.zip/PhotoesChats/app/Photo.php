<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Overtrue\LaravelFavorite\Traits\Favoriteable;

class Photo extends Model
{
    use Favoriteable;
    
    public function user()
    {
        return $this->belongsTo('App\User');
    }
    
    public function reviews()
    {
        return $this->hasMany('App\Review');
    }
}
