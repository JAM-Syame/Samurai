<?php

namespace App\Http\Controllers;

use App\Photo;
use App\Review;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Photo $photo, Request $request)
    {
        $review = new Review();
        $review->content = $request->input('content');
        $review->photo_id = $photo->id;
        $review->user_id = Auth::user()->id;
        $review->save();

        return redirect()->route('photos.show', $photo);
    }
}
