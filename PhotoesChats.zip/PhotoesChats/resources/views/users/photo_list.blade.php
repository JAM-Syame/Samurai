
@extends('layouts.app')

@section('content')
  	<h2>投稿写真一覧</h2>
  	
 	<div class="container-fluid">
	    @foreach($photolist as $photo)
	    @if ($loop->iteration % 4 == 1 || $loop->first)
	    <div class="row">
	    @endif
	    <div class="col-md-3" style="overflow:hidden;">
	      <div class="card">
	        <div class="card-body">
                <h3 class="card-title">{{$photo->title}}</h3>
                <img class="card-img-top img-fluid" src="{{ $url }}photos/{{$photo->user_id}}/{{$photo->url}}"/>
    			<form action="/photos/{{ $photo->id }}" method="POST" onsubmit="if(confirm('投稿写真を削除しますか？')) { return true } else {return false };">
                    <input type="hidden" name="_method" value="DELETE">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <button type="submit">写真削除</button>
                </form>
			</div>
		  </div>
		</div>
		@if ($loop->iteration % 4 == 0 || $loop->last)
		</div>
	    @endif
		@endforeach
	</div>
@endsection
	
