
@extends('layouts.app')

@section('content')
  	<h2>お気に入り一覧</h2>
  	
 	<div class="container-fluid">
	    @foreach($favoritelist as $favorite)
	    @if ($loop->iteration % 4 == 1 || $loop->first)
	    <div class="row">
	    @endif
	    <div class="col-md-3" style="overflow:hidden;">
	      <div class="card">
	        <div class="card-body">
                <h3 class="card-title">{{App\Photo::find($favorite->favoriteable_id)["title"]}}</h3>
                <img  class="card-img-top img-fluid" src="{{ $url }}photos/{{App\Photo::find($favorite->favoriteable_id)["user_id"]}}/{{App\Photo::find($favorite->favoriteable_id)["url"]}}"/>
			</div>
		  </div>
		</div>
		@if ($loop->iteration % 4 == 0 || $loop->last)
		</div>
	    @endif
		@endforeach
	</div>
@endsection
	
