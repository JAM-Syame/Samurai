
@extends('layouts.app')

@section('title', 'レビュー一覧')

@section('content')
  	<h2>レビュー一覧</h2>
  	
 	<div class="container-fluid">
	    @foreach($reviewlist as $review)
	    @if ($loop->iteration % 4 == 1 || $loop->first)
	    <div class="row">
	    @endif
	    <div class="col-md-3" style="overflow:hidden;">
	      <div class="card">
	        <div class="card-body">
                <h3 class="card-title">{{App\Photo::find($review->photo_id)->title}}</h3>
                {{$review->content}}
                <img class="card-img-top img-fluid" src="{{ $url }}photos/{{App\Photo::find($review->photo_id)->user_id}}/{{App\Photo::find($review->photo_id)->url}}"/>
			</div>
		  </div>
		</div>
		@if ($loop->iteration % 4 == 0 || $loop->last)
		</div>
	    @endif
		@endforeach
	</div>
@endsection
	
