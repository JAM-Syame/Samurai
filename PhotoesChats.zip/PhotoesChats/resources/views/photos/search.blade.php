
@extends('layouts.app')

@section('title', "詳細検索")

<h2>ユーザー</h2>

<form method="POST" action="/searchdetailresult">
{{ csrf_field() }}

<select name="user">
@foreach($users as $user)
<option value="{{$user->id}}">{{$user->name}}</option>
@endforeach
</select>

<h2>メーカー</h2>
<select name="maker">
@foreach($lenses as $lens)
<option value="{{$lens->id}}">{{$lens->name}}</option>
@endforeach
</select>

<h2>レンズタイプ</h2>
<select name="lens">
@foreach($makers as $maker)
<option value="{{$maker->id}}">{{$maker->name}}</option>
@endforeach
</select>

<h2>撮影エリア</h2>
<select name="area">
@foreach($areas as $area)
<option value="{{$area->id}}">{{$area->name}}</option>
@endforeach
</select>

<h2>アップロード日</h2>
<input type="text" name="uploadfrom" id="uploadfrom"/>～<input type="text" name="uploadto" id="uploadto"/>


    
    <input type="submit" value="検索する">
</form>