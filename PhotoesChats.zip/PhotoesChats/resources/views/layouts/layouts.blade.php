<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>@yield('title')</title>
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <link href="{{ asset('css/style.css') }}" rel="stylesheet">
        <style>
		.boxCol:after	{content: "";
			display: block;
			clear: both}
		
		.boxOneThird	{float: left;
			width: 33.3333%}
		
		.boxOneQuarter	{float: left;
			width: 25%}
			
		</style>
        <script language="javascript" type="text/javascript">
            function onLogout() {
        		$("#form_logout").attr("action","/logout");
                $('#form_logout').submit();
            }
        </script>
    </head>
    <body>
        @component('components.header')
        @endcomponent
        <div class="container">
            @yield('content')
        </div>

        $(function() {
            $( "#uploadfrom" ).datepicker({ dateFormat: "yy-mm-dd" });
            $( "#uploadto" ).datepicker({ dateFormat: "yy-mm-dd" });
        });
        </script> 
    </body>
</body>
</html> 